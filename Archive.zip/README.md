SecureAPI is a simple JWT authentication/authoriation solution using ASP.NET Web Api Core 3.1.

Make sure if you use this code to setup a real SecretKey in the appsetings.json.