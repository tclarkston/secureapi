﻿using System;
namespace WebApi.Entities
{
    public class AppSettings
    {
        public string SecretKey { get; set; }
    }
}
